<?php
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../includes/functions.php';

// Check if admin is logged in
if (!isAdminLoggedIn()) {
    header('Location: login.php');
    exit();
}

$error = '';
$success = '';
$formData = [
    'name' => '',
    'category' => 'slots',
    'logo_url' => '',
    'card_link' => '',
    'rating' => 4.5,
    'badge_1' => '',
    'badge_2' => '',
    'badge_1_type' => 'position',
    'badge_2_type' => 'category',
    'display_order' => 0,
    'status' => 1
];

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $formData = [
        'name' => trim($_POST['name'] ?? ''),
        'category' => $_POST['category'] ?? '',
        'logo_url' => trim($_POST['logo_url'] ?? ''),
        'card_link' => trim($_POST['card_link'] ?? ''),
        'rating' => floatval($_POST['rating'] ?? 4.5),
        'badge_1' => trim($_POST['badge_1'] ?? ''),
        'badge_2' => trim($_POST['badge_2'] ?? ''),
        'badge_1_type' => $_POST['badge_1_type'] ?? 'position',
        'badge_2_type' => $_POST['badge_2_type'] ?? 'category',
        'display_order' => intval($_POST['display_order'] ?? 0),
        'status' => isset($_POST['status']) ? 1 : 0
    ];
    
    // Validate required fields
    $errors = [];
    if (empty($formData['name'])) $errors[] = 'Card name is required';
    if (empty($formData['category'])) $errors[] = 'Category is required';
    if (empty($formData['logo_url'])) $errors[] = 'Logo URL is required';
    if (empty($formData['card_link'])) $errors[] = 'Card link is required';
    if (!filter_var($formData['logo_url'], FILTER_VALIDATE_URL)) $errors[] = 'Invalid Logo URL format';
    if (!filter_var($formData['card_link'], FILTER_VALIDATE_URL)) $errors[] = 'Invalid Card Link format';
    if ($formData['rating'] < 1 || $formData['rating'] > 5) $errors[] = 'Rating must be between 1 and 5';
    
    if (empty($errors)) {
        $id = addCard($formData);
        if ($id) {
            $success = "Card added successfully! <a href='index.php' style='color:#60a5fa;'>Back to Admin Panel</a>";
            // Reset form data
            $formData = [
                'name' => '',
                'category' => 'slots',
                'logo_url' => '',
                'card_link' => '',
                'rating' => 4.5,
                'badge_1' => '',
                'badge_2' => '',
                'badge_1_type' => 'position',
                'badge_2_type' => 'category',
                'display_order' => 0,
                'status' => 1
            ];
        } else {
            $error = 'Failed to add card. Please try again.';
        }
    } else {
        $error = implode('<br>', $errors);
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add Card - Admin Panel</title>
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800;900&display=swap" rel="stylesheet">
    <style>
        * { margin:0; padding:0; box-sizing:border-box; font-family:'Plus Jakarta Sans',sans-serif; }
        body { background:#0b0f19; color:#f8fafc; padding:24px; }
        .admin-wrapper { max-width:800px; margin:0 auto; }
        .admin-header { display:flex; justify-content:space-between; align-items:center; padding:20px 0; border-bottom:1px solid rgba(255,255,255,0.06); margin-bottom:30px; }
        .admin-header h1 { font-size:1.8rem; font-weight:800; color:#ffffff; }
        .admin-header h1 span { color:#3b82f6; }
        .form-container { background:#151b2c; border:1px solid rgba(255,255,255,0.06); border-radius:16px; padding:30px; }
        .form-group { margin-bottom:20px; }
        .form-group label { display:block; color:#cbd5e1; font-weight:600; font-size:0.9rem; margin-bottom:6px; }
        .form-group label .required { color:#ef4444; }
        .form-group input, .form-group select, .form-group textarea {
            width:100%; padding:12px 16px; background:#0f1422; border:1px solid rgba(255,255,255,0.1);
            border-radius:10px; color:#ffffff; font-size:0.95rem; transition:all 0.25s ease;
        }
        .form-group input:focus, .form-group select:focus, .form-group textarea:focus {
            outline:none; border-color:#3b82f6; background:#111827;
        }
        .form-group textarea { min-height:60px; resize:vertical; }
        .form-row { display:grid; grid-template-columns:1fr 1fr; gap:20px; }
        .form-actions { display:flex; gap:12px; margin-top:25px; }
        .btn { padding:12px 24px; border-radius:10px; font-weight:700; font-size:0.95rem; text-decoration:none; transition:all 0.2s ease; border:none; cursor:pointer; display:inline-flex; align-items:center; gap:8px; }
        .btn-primary { background:#3b82f6; color:#ffffff; }
        .btn-primary:hover { background:#2563eb; transform:translateY(-1px); }
        .btn-secondary { background:rgba(255,255,255,0.08); color:#cbd5e1; }
        .btn-secondary:hover { background:rgba(255,255,255,0.14); transform:translateY(-1px); }
        .alert { padding:14px 20px; border-radius:10px; margin-bottom:20px; font-weight:600; }
        .alert-success { background:rgba(34,197,94,0.1); border:1px solid rgba(34,197,94,0.2); color:#4ade80; }
        .alert-danger { background:rgba(239,68,68,0.1); border:1px solid rgba(239,68,68,0.2); color:#f87171; }
        .back-link { color:#94a3b8; text-decoration:none; font-weight:600; padding:8px 16px; border-radius:8px; background:rgba(255,255,255,0.04); transition:all 0.2s ease; }
        .back-link:hover { background:rgba(255,255,255,0.08); color:#ffffff; }
        @media (max-width:768px) {
            .form-row { grid-template-columns:1fr; }
            .form-actions { flex-direction:column; }
            .btn { justify-content:center; }
        }
    </style>
</head>
<body>
    <div class="admin-wrapper">
        <div class="admin-header">
            <h1>➕ Add New Card</h1>
            <a href="index.php" class="back-link">← Back to Panel</a>
        </div>

        <?php if ($success): ?>
            <div class="alert alert-success"><?php echo $success; ?></div>
        <?php endif; ?>
        <?php if ($error): ?>
            <div class="alert alert-danger"><?php echo $error; ?></div>
        <?php endif; ?>

        <div class="form-container">
            <form method="POST" action="">
                <div class="form-group">
                    <label>Card Name <span class="required">*</span></label>
                    <input type="text" name="name" value="<?php echo htmlspecialchars($formData['name']); ?>" placeholder="e.g., 1111Bet" required>
                </div>

                <div class="form-row">
                    <div class="form-group">
                        <label>Category <span class="required">*</span></label>
                        <select name="category" required>
                            <option value="slots" <?php echo $formData['category'] === 'slots' ? 'selected' : ''; ?>>Slots</option>
                            <option value="sports" <?php echo $formData['category'] === 'sports' ? 'selected' : ''; ?>>Sportsbook</option>
                            <option value="crypto" <?php echo $formData['category'] === 'crypto' ? 'selected' : ''; ?>>Crypto Play</option>
                            <option value="casino" <?php echo $formData['category'] === 'casino' ? 'selected' : ''; ?>>Live Casino</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label>Rating (1-5)</label>
                        <input type="number" name="rating" step="0.1" min="1" max="5" value="<?php echo $formData['rating']; ?>">
                    </div>
                </div>

                <div class="form-group">
                    <label>Logo URL <span class="required">*</span></label>
                    <input type="url" name="logo_url" value="<?php echo htmlspecialchars($formData['logo_url']); ?>" placeholder="https://example.com/logo.png" required>
                </div>

                <div class="form-group">
                    <label>Card Link <span class="required">*</span></label>
                    <input type="url" name="card_link" value="<?php echo htmlspecialchars($formData['card_link']); ?>" placeholder="https://example.com/card" required>
                </div>

                <div class="form-row">
                    <div class="form-group">
                        <label>Badge 1</label>
                        <input type="text" name="badge_1" value="<?php echo htmlspecialchars($formData['badge_1']); ?>" placeholder="e.g., Top Selected">
                    </div>
                    <div class="form-group">
                        <label>Badge 1 Type</label>
                        <select name="badge_1_type">
                            <option value="position" <?php echo $formData['badge_1_type'] === 'position' ? 'selected' : ''; ?>>Position</option>
                            <option value="category" <?php echo $formData['badge_1_type'] === 'category' ? 'selected' : ''; ?>>Category</option>
                        </select>
                    </div>
                </div>

                <div class="form-row">
                    <div class="form-group">
                        <label>Badge 2</label>
                        <input type="text" name="badge_2" value="<?php echo htmlspecialchars($formData['badge_2']); ?>" placeholder="e.g., Slots">
                    </div>
                    <div class="form-group">
                        <label>Badge 2 Type</label>
                        <select name="badge_2_type">
                            <option value="position" <?php echo $formData['badge_2_type'] === 'position' ? 'selected' : ''; ?>>Position</option>
                            <option value="category" <?php echo $formData['badge_2_type'] === 'category' ? 'selected' : ''; ?>>Category</option>
                        </select>
                    </div>
                </div>

                <div class="form-row">
                    <div class="form-group">
                        <label>Display Order</label>
                        <input type="number" name="display_order" value="<?php echo $formData['display_order']; ?>" min="0">
                    </div>
                    <div class="form-group">
                        <label style="display:flex; align-items:center; gap:10px; cursor:pointer;">
                            <input type="checkbox" name="status" <?php echo $formData['status'] ? 'checked' : ''; ?> style="width:auto;">
                            Active
                        </label>
                    </div>
                </div>

                <div class="form-actions">
                    <button type="submit" class="btn btn-primary">💾 Save Card</button>
                    <a href="index.php" class="btn btn-secondary">Cancel</a>
                </div>
            </form>
        </div>
    </div>
</body>
</html>