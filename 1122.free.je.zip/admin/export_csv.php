<?php
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../includes/functions.php';

// Check if admin is logged in
if (!isAdminLoggedIn()) {
    header('Location: login.php');
    exit();
}

$cards = getAllCards();

// Set headers for CSV download
header('Content-Type: text/csv; charset=utf-8');
header('Content-Disposition: attachment; filename="casino_cards_' . date('Y-m-d') . '.csv"');

// Open output stream
$output = fopen('php://output', 'w');

// Write headers
fputcsv($output, [
    'ID', 'Name', 'Category', 'Logo URL', 'Card Link', 'Rating',
    'Badge 1', 'Badge 2', 'Badge 1 Type', 'Badge 2 Type',
    'Display Order', 'Status', 'Created At', 'Updated At'
]);

// Write data rows
foreach ($cards as $card) {
    fputcsv($output, [
        $card['id'],
        $card['name'],
        $card['category'],
        $card['logo_url'],
        $card['card_link'],
        $card['rating'],
        $card['badge_1'],
        $card['badge_2'],
        $card['badge_1_type'],
        $card['badge_2_type'],
        $card['display_order'],
        $card['status'] ? 'Active' : 'Inactive',
        $card['created_at'],
        $card['updated_at']
    ]);
}

fclose($output);
exit();
?>