<?php
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../includes/functions.php';

// Check if admin is logged in
if (!isAdminLoggedIn()) {
    header('Location: login.php');
    exit();
}

$error = '';
$success = '';
$imported = 0;
$skipped = 0;

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_FILES['csv_file'])) {
    $file = $_FILES['csv_file'];
    
    // Check for upload errors
    if ($file['error'] !== UPLOAD_ERR_OK) {
        $error = 'File upload error. Please try again.';
    } elseif ($file['type'] !== 'text/csv' && $file['type'] !== 'application/vnd.ms-excel') {
        $error = 'Please upload a CSV file.';
    } else {
        // Process CSV
        $handle = fopen($file['tmp_name'], 'r');
        if ($handle !== false) {
            // Read headers
            $headers = fgetcsv($handle);
            
            // Map headers to database fields
            $fieldMap = array_flip($headers);
            
            while (($row = fgetcsv($handle)) !== false) {
                // Skip empty rows
                if (empty(array_filter($row))) continue;
                
                // Build data array
                $data = [
                    'name' => $row[$fieldMap['Name'] ?? 1] ?? '',
                    'category' => $row[$fieldMap['Category'] ?? 2] ?? '',
                    'logo_url' => $row[$fieldMap['Logo URL'] ?? 3] ?? '',
                    'card_link' => $row[$fieldMap['Card Link'] ?? 4] ?? '',
                    'rating' => $row[$fieldMap['Rating'] ?? 5] ?? 4.5,
                    'badge_1' => $row[$fieldMap['Badge 1'] ?? 6] ?? '',
                    'badge_2' => $row[$fieldMap['Badge 2'] ?? 7] ?? '',
                    'badge_1_type' => $row[$fieldMap['Badge 1 Type'] ?? 8] ?? 'position',
                    'badge_2_type' => $row[$fieldMap['Badge 2 Type'] ?? 9] ?? 'category',
                    'display_order' => $row[$fieldMap['Display Order'] ?? 10] ?? 0,
                    'status' => ($row[$fieldMap['Status'] ?? 11] ?? 'Active') === 'Active' ? 1 : 0
                ];
                
                // Validate required fields
                if (empty($data['name']) || empty($data['category'])) {
                    $skipped++;
                    continue;
                }
                
                // Add card
                if (addCard($data)) {
                    $imported++;
                } else {
                    $skipped++;
                }
            }
            
            fclose($handle);
            $success = "Import completed! $imported cards imported, $skipped skipped.";
        } else {
            $error = 'Unable to open CSV file.';
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Import CSV - Admin Panel</title>
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800;900&display=swap" rel="stylesheet">
    <style>
        * { margin:0; padding:0; box-sizing:border-box; font-family:'Plus Jakarta Sans',sans-serif; }
        body { background:#0b0f19; color:#f8fafc; padding:24px; }
        .admin-wrapper { max-width:800px; margin:0 auto; }
        .admin-header { display:flex; justify-content:space-between; align-items:center; padding:20px 0; border-bottom:1px solid rgba(255,255,255,0.06); margin-bottom:30px; }
        .admin-header h1 { font-size:1.8rem; font-weight:800; color:#ffffff; }
        .admin-header h1 span { color:#3b82f6; }
        .form-container { background:#151b2c; border:1px solid rgba(255,255,255,0.06); border-radius:16px; padding:30px; }
        .form-group { margin-bottom:20px; }
        .form-group label { display:block; color:#cbd5e1; font-weight:600; font-size:0.9rem; margin-bottom:6px; }
        .form-group input[type="file"] {
            width:100%; padding:12px; background:#0f1422; border:1px solid rgba(255,255,255,0.1);
            border-radius:10px; color:#ffffff; font-size:0.95rem;
        }
        .form-actions { display:flex; gap:12px; margin-top:25px; }
        .btn { padding:12px 24px; border-radius:10px; font-weight:700; font-size:0.95rem; text-decoration:none; transition:all 0.2s ease; border:none; cursor:pointer; display:inline-flex; align-items:center; gap:8px; }
        .btn-primary { background:#3b82f6; color:#ffffff; }
        .btn-primary:hover { background:#2563eb; transform:translateY(-1px); }
        .btn-secondary { background:rgba(255,255,255,0.08); color:#cbd5e1; }
        .btn-secondary:hover { background:rgba(255,255,255,0.14); transform:translateY(-1px); }
        .alert { padding:14px 20px; border-radius:10px; margin-bottom:20px; font-weight:600; }
        .alert-success { background:rgba(34,197,94,0.1); border:1px solid rgba(34,197,94,0.2); color:#4ade80; }
        .alert-danger { background:rgba(239,68,68,0.1); border:1px solid rgba(239,68,68,0.2); color:#f87171; }
        .back-link { color:#94a3b8; text-decoration:none; font-weight:600; padding:8px 16px; border-radius:8px; background:rgba(255,255,255,0.04); transition:all 0.2s ease; }
        .back-link:hover { background:rgba(255,255,255,0.08); color:#ffffff; }
        .sample-csv { margin-top:20px; padding:20px; background:#0f1422; border-radius:10px; font-size:0.85rem; color:#94a3b8; }
        .sample-csv code { color:#60a5fa; }
        @media (max-width:768px) {
            .form-actions { flex-direction:column; }
            .btn { justify-content:center; }
        }
    </style>
</head>
<body>
    <div class="admin-wrapper">
        <div class="admin-header">
            <h1>📥 Import CSV</h1>
            <a href="index.php" class="back-link">← Back to Panel</a>
        </div>

        <?php if ($success): ?>
            <div class="alert alert-success"><?php echo $success; ?></div>
        <?php endif; ?>
        <?php if ($error): ?>
            <div class="alert alert-danger"><?php echo htmlspecialchars($error); ?></div>
        <?php endif; ?>

        <div class="form-container">
            <form method="POST" action="" enctype="multipart/form-data">
                <div class="form-group">
                    <label>Choose CSV File</label>
                    <input type="file" name="csv_file" accept=".csv" required>
                    <p style="color:#64748b; font-size:0.8rem; margin-top:6px;">Max file size: 2MB</p>
                </div>

                <div class="form-actions">
                    <button type="submit" class="btn btn-primary">📤 Import Cards</button>
                    <a href="index.php" class="btn btn-secondary">Cancel</a>
                </div>
            </form>

            <div class="sample-csv">
                <h4 style="color:#f8fafc; margin-bottom:10px;">📋 Sample CSV Format:</h4>
                <code>
                    Name,Category,Logo URL,Card Link,Rating,Badge 1,Badge 2,Badge 1 Type,Badge 2 Type,Display Order,Status<br>
                    1111Bet,slots,https://example.com/logo.png,https://example.com,4.9,Top Selected,Slots,position,category,0,Active
                </code>
                <p style="margin-top:10px; color:#64748b;">
                    <strong>Note:</strong> Download the <a href="export_csv.php" style="color:#3b82f6;">Export CSV</a> to see the current format.
                </p>
            </div>
        </div>
    </div>
</body>
</html>