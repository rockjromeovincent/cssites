<?php
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../includes/functions.php';

// Check if admin is logged in
if (!isAdminLoggedIn()) {
    header('Location: login.php');
    exit();
}

// Handle delete request
if (isset($_GET['delete']) && is_numeric($_GET['delete'])) {
    $id = intval($_GET['delete']);
    if (deleteCard($id)) {
        $success = "Card deleted successfully!";
    } else {
        $error = "Failed to delete card.";
    }
}

// Handle permanent delete
if (isset($_GET['permanent_delete']) && is_numeric($_GET['permanent_delete'])) {
    $id = intval($_GET['permanent_delete']);
    if (permanentlyDeleteCard($id)) {
        $success = "Card permanently deleted!";
    } else {
        $error = "Failed to permanently delete card.";
    }
}

// Handle restore request
if (isset($_GET['restore']) && is_numeric($_GET['restore'])) {
    $id = intval($_GET['restore']);
    $conn = getDBConnection();
    $sql = "UPDATE casino_cards SET status = 1 WHERE id = $id";
    if ($conn->query($sql)) {
        $success = "Card restored successfully!";
    } else {
        $error = "Failed to restore card.";
    }
    $conn->close();
}

// Get all cards (including inactive ones for admin)
$conn = getDBConnection();
$sql = "SELECT * FROM casino_cards ORDER BY display_order ASC, id DESC";
$result = $conn->query($sql);
$cards = [];
$totalCards = 0;
$activeCards = 0;
$inactiveCards = 0;
$categoryCounts = [];

if ($result && $result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $cards[] = $row;
        $totalCards++;
        if ($row['status'] == 1) {
            $activeCards++;
        } else {
            $inactiveCards++;
        }
        $categoryCounts[$row['category']] = ($categoryCounts[$row['category']] ?? 0) + 1;
    }
}
$conn->close();
?>
<?php include_once __DIR__ . '/includes/header.php'; ?>

<div class="admin-header">
    <div>
        <h1>🎰 11/22 <span>Luck</span> Admin</h1>
        <p style="color:#94a3b8; font-size:0.9rem;">Welcome, <?php echo htmlspecialchars($_SESSION['admin_username'] ?? 'Admin'); ?>!</p>
    </div>
    <div class="admin-actions">
        <a href="../index.php" class="btn btn-secondary" target="_blank">🌐 View Site</a>
        <a href="add_card.php" class="btn btn-success">➕ Add New Card</a>
        <a href="import_csv.php" class="btn btn-warning">📥 Import CSV</a>
        <a href="export_csv.php" class="btn btn-primary">📤 Export CSV</a>
        <a href="logout.php" class="btn btn-danger">🚪 Logout</a>
    </div>
</div>

<?php if (isset($success)): ?>
    <div class="alert alert-success"><?php echo htmlspecialchars($success); ?></div>
<?php endif; ?>
<?php if (isset($error)): ?>
    <div class="alert alert-danger"><?php echo htmlspecialchars($error); ?></div>
<?php endif; ?>

<!-- Statistics Cards -->
<div style="display:grid; grid-template-columns:repeat(auto-fit, minmax(150px, 1fr)); gap:15px; margin-bottom:30px;">
    <div style="background:#151b2c; border:1px solid rgba(255,255,255,0.06); border-radius:14px; padding:18px 20px;">
        <div style="color:#94a3b8; font-size:0.8rem; font-weight:600; text-transform:uppercase; letter-spacing:0.03em;">Total Cards</div>
        <div style="font-size:2rem; font-weight:800; color:#ffffff; margin-top:4px;"><?php echo $totalCards; ?></div>
    </div>
    <div style="background:#151b2c; border:1px solid rgba(34,197,94,0.15); border-radius:14px; padding:18px 20px;">
        <div style="color:#94a3b8; font-size:0.8rem; font-weight:600; text-transform:uppercase; letter-spacing:0.03em;">Active</div>
        <div style="font-size:2rem; font-weight:800; color:#4ade80; margin-top:4px;"><?php echo $activeCards; ?></div>
    </div>
    <div style="background:#151b2c; border:1px solid rgba(239,68,68,0.15); border-radius:14px; padding:18px 20px;">
        <div style="color:#94a3b8; font-size:0.8rem; font-weight:600; text-transform:uppercase; letter-spacing:0.03em;">Inactive</div>
        <div style="font-size:2rem; font-weight:800; color:#f87171; margin-top:4px;"><?php echo $inactiveCards; ?></div>
    </div>
    <?php foreach ($categoryCounts as $category => $count): ?>
        <div style="background:#151b2c; border:1px solid rgba(255,255,255,0.06); border-radius:14px; padding:18px 20px;">
            <div style="color:#94a3b8; font-size:0.8rem; font-weight:600; text-transform:uppercase; letter-spacing:0.03em;"><?php echo getCategoryLabel($category); ?></div>
            <div style="font-size:2rem; font-weight:800; color:#60a5fa; margin-top:4px;"><?php echo $count; ?></div>
        </div>
    <?php endforeach; ?>
</div>

<!-- Cards Table -->
<div style="background:#151b2c; border:1px solid rgba(255,255,255,0.06); border-radius:16px; overflow-x:auto; padding:20px;">
    <table style="width:100%; border-collapse:collapse; min-width:800px;">
        <thead style="border-bottom:1px solid rgba(255,255,255,0.06);">
            <tr>
                <th style="text-align:left; padding:14px 12px; color:#94a3b8; font-size:0.8rem; font-weight:700; text-transform:uppercase;">ID</th>
                <th style="text-align:left; padding:14px 12px; color:#94a3b8; font-size:0.8rem; font-weight:700; text-transform:uppercase;">Logo</th>
                <th style="text-align:left; padding:14px 12px; color:#94a3b8; font-size:0.8rem; font-weight:700; text-transform:uppercase;">Name</th>
                <th style="text-align:left; padding:14px 12px; color:#94a3b8; font-size:0.8rem; font-weight:700; text-transform:uppercase;">Category</th>
                <th style="text-align:left; padding:14px 12px; color:#94a3b8; font-size:0.8rem; font-weight:700; text-transform:uppercase;">Rating</th>
                <th style="text-align:left; padding:14px 12px; color:#94a3b8; font-size:0.8rem; font-weight:700; text-transform:uppercase;">Badges</th>
                <th style="text-align:left; padding:14px 12px; color:#94a3b8; font-size:0.8rem; font-weight:700; text-transform:uppercase;">Status</th>
                <th style="text-align:left; padding:14px 12px; color:#94a3b8; font-size:0.8rem; font-weight:700; text-transform:uppercase;">Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php if (empty($cards)): ?>
                <tr>
                    <td colspan="8" style="text-align:center; padding:60px 20px; color:#94a3b8;">
                        <h3 style="color:#f8fafc; margin-bottom:10px;">No cards found</h3>
                        <p>Start by adding your first casino card.</p>
                        <a href="add_card.php" class="btn btn-success" style="margin-top:15px;">➕ Add New Card</a>
                    </td>
                </tr>
            <?php else: ?>
                <?php foreach ($cards as $card): ?>
                    <tr>
                        <td style="padding:14px 12px; border-bottom:1px solid rgba(255,255,255,0.04);">#<?php echo $card['id']; ?></td>
                        <td style="padding:14px 12px; border-bottom:1px solid rgba(255,255,255,0.04);">
                            <?php if (filter_var($card['logo_url'], FILTER_VALIDATE_URL)): ?>
                                <img src="<?php echo htmlspecialchars($card['logo_url']); ?>" alt="<?php echo htmlspecialchars($card['name']); ?>" style="width:50px; height:30px; object-fit:contain; background:#0f1422; border-radius:6px; padding:4px;">
                            <?php else: ?>
                                <span style="font-size:0.75rem; color:#64748b;">No logo</span>
                            <?php endif; ?>
                        </td>
                        <td style="padding:14px 12px; border-bottom:1px solid rgba(255,255,255,0.04);"><strong><?php echo htmlspecialchars($card['name']); ?></strong></td>
                        <td style="padding:14px 12px; border-bottom:1px solid rgba(255,255,255,0.04);"><?php echo getCategoryLabel($card['category']); ?></td>
                        <td style="padding:14px 12px; border-bottom:1px solid rgba(255,255,255,0.04);">⭐ <?php echo $card['rating']; ?></td>
                        <td style="padding:14px 12px; border-bottom:1px solid rgba(255,255,255,0.04);">
                            <?php if ($card['badge_1']): ?>
                                <span style="font-size:0.7rem; background:rgba(59,130,246,0.1); padding:2px 8px; border-radius:4px; color:#60a5fa;"><?php echo htmlspecialchars($card['badge_1']); ?></span>
                            <?php endif; ?>
                            <?php if ($card['badge_2']): ?>
                                <span style="font-size:0.7rem; background:rgba(255,255,255,0.05); padding:2px 8px; border-radius:4px; color:#cbd5e1;"><?php echo htmlspecialchars($card['badge_2']); ?></span>
                            <?php endif; ?>
                        </td>
                        <td style="padding:14px 12px; border-bottom:1px solid rgba(255,255,255,0.04);">
                            <span style="display:inline-block; padding:3px 10px; border-radius:20px; font-size:0.7rem; font-weight:700; <?php echo $card['status'] ? 'background:rgba(34,197,94,0.15); color:#4ade80;' : 'background:rgba(239,68,68,0.15); color:#f87171;'; ?>">
                                <?php echo $card['status'] ? 'Active' : 'Inactive'; ?>
                            </span>
                        </td>
                        <td style="padding:14px 12px; border-bottom:1px solid rgba(255,255,255,0.04);">
                            <div style="display:flex; gap:6px; flex-wrap:wrap;">
                                <a href="edit_card.php?id=<?php echo $card['id']; ?>" style="padding:5px 12px; border-radius:6px; font-size:0.75rem; font-weight:600; text-decoration:none; background:rgba(59,130,246,0.15); color:#60a5fa; transition:all 0.2s ease;">✏️ Edit</a>
                                <?php if ($card['status'] == 0): ?>
                                    <a href="?restore=<?php echo $card['id']; ?>" style="padding:5px 12px; border-radius:6px; font-size:0.75rem; font-weight:600; text-decoration:none; background:rgba(34,197,94,0.15); color:#4ade80; transition:all 0.2s ease;">↩️ Restore</a>
                                <?php endif; ?>
                                <a href="?delete=<?php echo $card['id']; ?>" style="padding:5px 12px; border-radius:6px; font-size:0.75rem; font-weight:600; text-decoration:none; background:rgba(239,68,68,0.15); color:#f87171; transition:all 0.2s ease;" onclick="return confirm('Are you sure you want to delete this card?')">🗑️ Delete</a>
                            </div>
                        </td>
                    </tr>
                <?php endforeach; ?>
            <?php endif; ?>
        </tbody>
    </table>
</div>

<?php include_once __DIR__ . '/includes/footer.php'; ?>