<?php
// Database configuration
define('DB_HOST', 'sql208.infinityfree.com');
define('DB_USER', 'if0_42323847');
define('DB_PASS', '1122PasswordBd');
define('DB_NAME', 'if0_42323847_1122');

// Create connection
function getDBConnection() {
    try {
        $conn = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);
        
        if ($conn->connect_error) {
            throw new Exception("Connection failed: " . $conn->connect_error);
        }
        
        $conn->set_charset("utf8mb4");
        return $conn;
    } catch (Exception $e) {
        die("Database Connection Error: " . $e->getMessage());
    }
}

// Create cards table if not exists
function createCardsTable() {
    $conn = getDBConnection();
    
    $sql = "CREATE TABLE IF NOT EXISTS casino_cards (
        id INT AUTO_INCREMENT PRIMARY KEY,
        name VARCHAR(100) NOT NULL,
        category VARCHAR(50) NOT NULL,
        logo_url VARCHAR(500) NOT NULL,
        card_link VARCHAR(500) NOT NULL,
        rating DECIMAL(3,1) DEFAULT 4.5,
        badge_1 VARCHAR(100),
        badge_2 VARCHAR(100),
        badge_1_type VARCHAR(20) DEFAULT 'position',
        badge_2_type VARCHAR(20) DEFAULT 'category',
        display_order INT DEFAULT 0,
        status TINYINT(1) DEFAULT 1,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        INDEX idx_category (category),
        INDEX idx_status (status)
    )";
    
    if ($conn->query($sql) === TRUE) {
        return true;
    } else {
        die("Error creating table: " . $conn->error);
    }
    
    $conn->close();
}

// Initialize table
createCardsTable();

// Start session for admin login
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
?>