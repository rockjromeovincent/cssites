-- Create database (if needed)
CREATE DATABASE IF NOT EXISTS if0_42323847_1122;
USE if0_42323847_1122;

-- Create casino_cards table
CREATE TABLE IF NOT EXISTS casino_cards (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    category VARCHAR(50) NOT NULL,
    logo_url VARCHAR(500) NOT NULL,
    card_link VARCHAR(500) NOT NULL,
    rating DECIMAL(3,1) DEFAULT 4.5,
    badge_1 VARCHAR(100),
    badge_2 VARCHAR(100),
    badge_1_type VARCHAR(20) DEFAULT 'position',
    badge_2_type VARCHAR(20) DEFAULT 'category',
    display_order INT DEFAULT 0,
    status TINYINT(1) DEFAULT 1,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_category (category),
    INDEX idx_status (status)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Insert sample data from your existing cards
INSERT INTO casino_cards (name, category, logo_url, card_link, rating, badge_1, badge_2, badge_1_type, badge_2_type, display_order, status) VALUES
('1111Bet', 'slots', 'https://images.3521315.com/wsd-images-prod/111bdtf7/fe_setting/web_logo/wps_%E6%AD%A3%E7%A1%AE_20250906183416.png', 'http://www.1111bet14.com/?r=qnn0732', 4.9, 'Top Selected', 'Slots', 'position', 'category', 0, 1),
('BetVisa', 'sports', 'https://betvisa.st/logo.png', 'https://betvisa.st/logo.png', 4.5, 'Verified', 'Sports', 'position', 'category', 0, 1),
('Stake.com', 'crypto', '', '#stake', 4.8, 'Instant Cashout', 'Crypto Play', 'position', 'category', 0, 1),
('Evolution Elite', 'casino', '', '#evo', 4.6, 'Real Dealers', 'Live Casino', 'position', 'category', 0, 1),
('BC.Game Arena', 'slots', '', '#bcgame', 4.7, 'Huge Jackpots', 'Slots', 'position', 'category', 0, 1),
('1xBet Premium', 'sports', '', '#1xbet', 4.4, 'High Odds', 'Sportsbook', 'position', 'category', 0, 1),
('Roobet Hub', 'crypto', '', '#roobet', 4.5, 'Web3 Connected', 'Crypto Play', 'position', 'category', 0, 1),
('Pragmatic Club', 'casino', '', '#pragmatic', 4.9, 'Popular Room', 'Live Casino', 'position', 'category', 0, 1),
('888Casino', 'slots', '', '#888', 4.6, 'Classic Pick', 'Slots', 'position', 'category', 0, 1),
('Bet365 Sports', 'sports', '', '#bet365', 4.9, 'Global Rank #1', 'Sportsbook', 'position', 'category', 0, 1);