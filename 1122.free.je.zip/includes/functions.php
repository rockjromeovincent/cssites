<?php
require_once __DIR__ . '/../config/database.php';

// Escape and sanitize input
function sanitizeInput($data) {
    $data = trim($data);
    $data = stripslashes($data);
    $data = htmlspecialchars($data);
    return $data;
}

// Get all cards
function getAllCards($limit = null, $offset = null) {
    $conn = getDBConnection();
    $sql = "SELECT * FROM casino_cards WHERE status = 1 ORDER BY display_order ASC, id DESC";
    
    if ($limit !== null) {
        $sql .= " LIMIT " . intval($limit);
        if ($offset !== null) {
            $sql .= " OFFSET " . intval($offset);
        }
    }
    
    $result = $conn->query($sql);
    $cards = [];
    
    if ($result && $result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            $cards[] = $row;
        }
    }
    
    $conn->close();
    return $cards;
}

// Get single card by ID
function getCardById($id) {
    $conn = getDBConnection();
    $id = intval($id);
    
    $sql = "SELECT * FROM casino_cards WHERE id = $id";
    $result = $conn->query($sql);
    
    $card = null;
    if ($result && $result->num_rows > 0) {
        $card = $result->fetch_assoc();
    }
    
    $conn->close();
    return $card;
}

// Add new card
function addCard($data) {
    $conn = getDBConnection();
    
    $name = sanitizeInput($data['name']);
    $category = sanitizeInput($data['category']);
    $logo_url = sanitizeInput($data['logo_url']);
    $card_link = sanitizeInput($data['card_link']);
    $rating = floatval($data['rating']);
    $badge_1 = sanitizeInput($data['badge_1']);
    $badge_2 = sanitizeInput($data['badge_2']);
    $badge_1_type = sanitizeInput($data['badge_1_type']);
    $badge_2_type = sanitizeInput($data['badge_2_type']);
    $display_order = intval($data['display_order']);
    $status = isset($data['status']) ? intval($data['status']) : 1;
    
    $sql = "INSERT INTO casino_cards (
        name, category, logo_url, card_link, rating, 
        badge_1, badge_2, badge_1_type, badge_2_type, 
        display_order, status
    ) VALUES (
        '$name', '$category', '$logo_url', '$card_link', $rating,
        '$badge_1', '$badge_2', '$badge_1_type', '$badge_2_type',
        $display_order, $status
    )";
    
    $result = $conn->query($sql);
    $insertId = $conn->insert_id;
    $conn->close();
    
    return $result ? $insertId : false;
}

// Update card
function updateCard($id, $data) {
    $conn = getDBConnection();
    $id = intval($id);
    
    $name = sanitizeInput($data['name']);
    $category = sanitizeInput($data['category']);
    $logo_url = sanitizeInput($data['logo_url']);
    $card_link = sanitizeInput($data['card_link']);
    $rating = floatval($data['rating']);
    $badge_1 = sanitizeInput($data['badge_1']);
    $badge_2 = sanitizeInput($data['badge_2']);
    $badge_1_type = sanitizeInput($data['badge_1_type']);
    $badge_2_type = sanitizeInput($data['badge_2_type']);
    $display_order = intval($data['display_order']);
    $status = isset($data['status']) ? intval($data['status']) : 1;
    
    $sql = "UPDATE casino_cards SET 
        name = '$name',
        category = '$category',
        logo_url = '$logo_url',
        card_link = '$card_link',
        rating = $rating,
        badge_1 = '$badge_1',
        badge_2 = '$badge_2',
        badge_1_type = '$badge_1_type',
        badge_2_type = '$badge_2_type',
        display_order = $display_order,
        status = $status
    WHERE id = $id";
    
    $result = $conn->query($sql);
    $conn->close();
    
    return $result;
}

// Delete card (soft delete - set status to 0)
function deleteCard($id) {
    $conn = getDBConnection();
    $id = intval($id);
    
    $sql = "UPDATE casino_cards SET status = 0 WHERE id = $id";
    $result = $conn->query($sql);
    $conn->close();
    
    return $result;
}

// Permanently delete card
function permanentlyDeleteCard($id) {
    $conn = getDBConnection();
    $id = intval($id);
    
    $sql = "DELETE FROM casino_cards WHERE id = $id";
    $result = $conn->query($sql);
    $conn->close();
    
    return $result;
}

// Check if admin is logged in
function isAdminLoggedIn() {
    return isset($_SESSION['admin_logged_in']) && $_SESSION['admin_logged_in'] === true;
}

// Generate star rating HTML
function generateStars($rating) {
    $fullStars = floor($rating);
    $hasHalf = ($rating - $fullStars) >= 0.5;
    $emptyStars = 5 - $fullStars - ($hasHalf ? 1 : 0);
    
    $html = '';
    for ($i = 0; $i < $fullStars; $i++) {
        $html .= '<svg viewBox="0 0 24 24"><path d="M12 17.27L18.18 21l-1.64-7.03L22 9.24l-7.19-.61L12 2 9.19 8.63 2 9.24l5.46 4.73L5.82 21z"/></svg>';
    }
    if ($hasHalf) {
        $html .= '<svg viewBox="0 0 24 24"><path d="M12 17.27L18.18 21l-1.64-7.03L22 9.24l-7.19-.61L12 2 9.19 8.63 2 9.24l5.46 4.73L5.82 21z" style="opacity:0.5"/></svg>';
    }
    for ($i = 0; $i < $emptyStars; $i++) {
        $html .= '<svg viewBox="0 0 24 24" style="color: #334155;"><path d="M12 17.27L18.18 21l-1.64-7.03L22 9.24l-7.19-.61L12 2 9.19 8.63 2 9.24l5.46 4.73L5.82 21z"/></svg>';
    }
    return $html;
}

// Get category label
function getCategoryLabel($category) {
    $labels = [
        'slots' => 'Slots',
        'sports' => 'Sportsbook',
        'crypto' => 'Crypto Play',
        'casino' => 'Live Casino'
    ];
    return isset($labels[$category]) ? $labels[$category] : $category;
}

// Get card count
function getCardCount() {
    $conn = getDBConnection();
    $sql = "SELECT COUNT(*) as total FROM casino_cards WHERE status = 1";
    $result = $conn->query($sql);
    $count = 0;
    if ($result && $row = $result->fetch_assoc()) {
        $count = $row['total'];
    }
    $conn->close();
    return $count;
}
?>