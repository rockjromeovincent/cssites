<?php
// Check if admin is logged in
if (!isAdminLoggedIn()) {
    header('Location: login.php');
    exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Panel - 11/22 Luck</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800;900&display=swap" rel="stylesheet">
    <style>
        * { margin:0; padding:0; box-sizing:border-box; font-family:'Plus Jakarta Sans',sans-serif; }
        body { background:#0b0f19; color:#f8fafc; padding:24px; min-height:100vh; }
        .admin-wrapper { max-width:1400px; margin:0 auto; }
        .admin-header { display:flex; justify-content:space-between; align-items:center; padding:20px 0; border-bottom:1px solid rgba(255,255,255,0.06); margin-bottom:30px; flex-wrap:wrap; gap:15px; }
        .admin-header h1 { font-size:1.8rem; font-weight:800; color:#ffffff; }
        .admin-header h1 span { color:#3b82f6; }
        .admin-actions { display:flex; gap:12px; flex-wrap:wrap; }
        .btn { padding:10px 20px; border-radius:10px; font-weight:700; font-size:0.9rem; text-decoration:none; transition:all 0.2s ease; display:inline-flex; align-items:center; gap:8px; border:none; cursor:pointer; }
        .btn-primary { background:#3b82f6; color:#ffffff; }
        .btn-primary:hover { background:#2563eb; transform:translateY(-1px); }
        .btn-success { background:#22c55e; color:#ffffff; }
        .btn-success:hover { background:#16a34a; transform:translateY(-1px); }
        .btn-danger { background:#ef4444; color:#ffffff; }
        .btn-danger:hover { background:#dc2626; transform:translateY(-1px); }
        .btn-warning { background:#f59e0b; color:#ffffff; }
        .btn-warning:hover { background:#d97706; transform:translateY(-1px); }
        .btn-secondary { background:rgba(255,255,255,0.08); color:#cbd5e1; }
        .btn-secondary:hover { background:rgba(255,255,255,0.14); transform:translateY(-1px); }
        .alert { padding:14px 20px; border-radius:10px; margin-bottom:20px; font-weight:600; }
        .alert-success { background:rgba(34,197,94,0.1); border:1px solid rgba(34,197,94,0.2); color:#4ade80; }
        .alert-danger { background:rgba(239,68,68,0.1); border:1px solid rgba(239,68,68,0.2); color:#f87171; }
        .back-link { color:#94a3b8; text-decoration:none; font-weight:600; padding:8px 16px; border-radius:8px; background:rgba(255,255,255,0.04); transition:all 0.2s ease; }
        .back-link:hover { background:rgba(255,255,255,0.08); color:#ffffff; }
        @media (max-width:768px) {
            body { padding:12px; }
            .admin-header { flex-direction:column; align-items:stretch; text-align:center; }
            .admin-actions { justify-content:center; }
        }
    </style>
</head>
<body>
    <div class="admin-wrapper">