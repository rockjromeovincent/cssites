<?php
require_once __DIR__ . '/config/database.php';
require_once __DIR__ . '/includes/functions.php';

// Get all cards from database
$cards = getAllCards(20); // Get 20 cards max
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>11/22 Luck - Premium Casino Platforms</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800;900&display=swap" rel="stylesheet">
    
    <style>
        /* Base Configuration - Restored original clean dark theme colors */
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Plus Jakarta Sans', sans-serif;
        }

        body {
            background-color: #0b0f19;
            background-image: radial-gradient(circle at 50% -20%, rgba(59, 130, 246, 0.1) 0%, transparent 50%);
            background-attachment: fixed;
            color: #f8fafc;
            padding-top: 104px;
            padding-bottom: 60px;
            display: flex;
            flex-direction: column;
            align-items: center;
            min-height: 100vh;
        }

        /* ==========================================
           11/22 LUCK STICKY GLASS HEADER
           ========================================== */
        .site-header {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 76px;
            background: rgba(11, 15, 25, 0.85);
            backdrop-filter: blur(20px);
            -webkit-backdrop-filter: blur(20px);
            border-bottom: 1px solid rgba(255, 255, 255, 0.06);
            z-index: 1000;
            display: flex;
            justify-content: center;
            align-items: center;
            padding: 0 24px;
        }

        .header-container {
            width: 100%;
            max-width: 1200px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        /* Brand Logo Design: 11/22 Luck */
        .brand-logo {
            font-size: 1.4rem;
            font-weight: 800;
            color: #ffffff;
            text-decoration: none;
            display: flex;
            align-items: center;
            gap: 10px;
            letter-spacing: -0.03em;
        }

        .brand-logo-icon {
            background: linear-gradient(135deg, #3b82f6 0%, #1d4ed8 100%);
            width: 34px;
            height: 34px;
            border-radius: 8px;
            display: flex;
            align-items: center;
            justify-content: center;
            box-shadow: 0 4px 14px rgba(59, 130, 246, 0.3);
        }

        .brand-logo span {
            color: #3b82f6;
            font-weight: 900;
        }

        .nav-menu {
            display: flex;
            align-items: center;
            gap: 20px;
            list-style: none;
        }

        .nav-link {
            font-size: 0.9rem;
            font-weight: 600;
            color: #94a3b8;
            text-decoration: none;
            transition: all 0.25s ease;
            display: flex;
            align-items: center;
            gap: 6px;
            padding: 8px 12px;
            border-radius: 8px;
        }

        .nav-link svg {
            width: 18px;
            height: 18px;
            transition: transform 0.2s ease;
        }

        .nav-link:hover, .nav-link.active {
            color: #ffffff;
            background: rgba(255, 255, 255, 0.04);
        }
        
        .nav-link:hover svg {
            transform: translateY(-2px);
        }

        .header-cta {
            background: #3b82f6;
            color: #ffffff !important;
            padding: 10px 20px;
            border-radius: 10px;
            font-weight: 700;
            box-shadow: 0 4px 15px rgba(59, 130, 246, 0.25);
            transition: all 0.2s ease;
        }

        .header-cta:hover {
            background: #2563eb;
            transform: translateY(-1px);
        }

        /* Mobile Hamburger Trigger */
        .hamburger {
            display: none;
            background: rgba(255, 255, 255, 0.04);
            border: 1px solid rgba(255, 255, 255, 0.08);
            border-radius: 8px;
            cursor: pointer;
            padding: 10px;
            z-index: 1100;
        }

        .hamburger-box {
            width: 20px;
            height: 14px;
            display: flex;
            flex-direction: column;
            justify-content: space-between;
        }

        .hamburger-inner {
            width: 100%;
            height: 2px;
            background-color: #f1f5f9;
            border-radius: 2px;
            transition: all 0.2s ease-in-out;
        }

        /* ==========================================
           CASINO ADVANCED FILTER WRAPPER 
           ========================================== */
        .filter-wrapper {
            width: 100%;
            max-width: 1200px; 
            background: #1e2640; 
            border: 1px solid rgba(255, 255, 255, 0.09);
            border-radius: 16px;
            padding: 14px 20px; 
            margin-bottom: 24px;
            display: flex;
            flex-direction: column;
            gap: 12px; 
            box-shadow: 0 16px 40px rgba(0, 0, 0, 0.3);
        }

        .search-container {
            position: relative;
            width: 100%;
        }

        .search-input {
            width: 100%;
            height: 44px; 
            background: #0f1422;
            border: 1px solid rgba(255, 255, 255, 0.12);
            border-radius: 10px;
            padding: 0 16px 0 44px;
            color: #ffffff;
            font-size: 0.92rem;
            font-weight: 500;
            outline: none;
            transition: all 0.25s ease;
        }

        .search-input:focus {
            border-color: #3b82f6;
            background: #111827;
        }

        .search-icon {
            position: absolute;
            left: 16px;
            top: 50%;
            transform: translateY(-50%);
            fill: none;
            stroke: #94a3b8;
            pointer-events: none;
            width: 18px;
            height: 18px;
        }

        .search-input:focus + .search-icon {
            stroke: #3b82f6;
        }

        .filter-pills {
            display: flex;
            flex-wrap: wrap;
            gap: 8px;
            border-top: 1px solid rgba(255, 255, 255, 0.08);
            padding-top: 12px; 
        }

        /* Modern Filter Buttons Styling */
        .filter-btn {
            background: rgba(255, 255, 255, 0.05);
            border: none;
            color: #cbd5e1;
            padding: 8px 16px; 
            border-radius: 20px; 
            font-size: 0.85rem;
            font-weight: 600;
            cursor: pointer;
            display: flex;
            align-items: center;
            gap: 8px;
            transition: all 0.2s cubic-bezier(0.4, 0, 0.2, 1);
        }

        .filter-btn svg { 
            width: 15px; 
            height: 15px; 
            opacity: 0.8;
            transition: transform 0.2s ease;
        }

        .filter-btn:hover {
            background: rgba(255, 255, 255, 0.12);
            color: #ffffff;
        }
        
        .filter-btn:hover svg {
            transform: scale(1.05);
        }

        .filter-btn.active {
            background: #3b82f6; 
            color: #ffffff;
            font-weight: 700;
            box-shadow: 0 4px 12px rgba(59, 130, 246, 0.3);
        }

        .filter-btn.active svg {
            opacity: 1;
        }

        /* ==========================================
           RE-ARCHITECTED CARDS CONTAINER
           ========================================== */
        .cards-container {
            width: 100%;
            max-width: 1200px;
            display: grid;
            grid-template-columns: 190px 1fr 190px;
            column-gap: 36px;
            align-items: start;
        }

        .cards-feed-column {
            display: flex;
            flex-direction: column;
            gap: 16px;
            width: 100%;
        }

        /* ==========================================
           MODERN RE-DESIGNED ANIMATED SIDE BANNERS
           ========================================== */
        .cards-container-banner {
            position: sticky;
            top: 100px;
            height: 540px;
            background: linear-gradient(180deg, #0e1322 0%, #080c16 100%);
            border: 1px solid rgba(255, 255, 255, 0.05);
            border-radius: 20px;
            padding: 28px 16px;
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: space-between;
            text-align: center;
            text-decoration: none;
            overflow: hidden;
            box-shadow: 0 12px 32px rgba(0,0,0,0.4);
            transition: border-color 0.25s ease, box-shadow 0.25s ease;
        }

        .cards-container-banner::before {
            content: '';
            position: absolute;
            top: -50%;
            left: -150%;
            width: 60%;
            height: 200%;
            background: linear-gradient(
                90deg, 
                transparent, 
                rgba(255, 255, 255, 0.03), 
                transparent
            );
            transform: rotate(25deg);
            animation: luxuryRay 4.5s infinite ease-in-out;
            pointer-events: none;
        }

        @keyframes luxuryRay {
            0% { left: -150%; }
            50% { left: 150%; }
            100% { left: 150%; }
        }

        .banner-glow-element {
            position: absolute;
            width: 130px;
            height: 130px;
            background: #e2b857;
            filter: blur(55px);
            opacity: 0.05;
            top: 20%;
            pointer-events: none;
        }

        .banner-tag {
            font-size: 0.68rem;
            text-transform: uppercase;
            font-weight: 800;
            color: #e2b857;
            background: rgba(226, 184, 87, 0.08);
            border: 1px solid rgba(226, 184, 87, 0.15);
            padding: 6px 12px;
            border-radius: 100px;
            letter-spacing: 0.06em;
        }

        .banner-title {
            font-size: 1.15rem;
            font-weight: 900;
            color: #ffffff;
            line-height: 1.3;
            letter-spacing: -0.01em;
        }

        .banner-title span {
            color: #94a3b8;
            display: block;
            font-size: 1rem;
            font-weight: 600;
            margin-top: 2px;
        }

        .banner-graphic {
            position: relative;
            width: 80px;
            height: 80px;
            background: rgba(255, 255, 255, 0.01);
            border: 1px solid rgba(255, 255, 255, 0.04);
            border-radius: 18px;
            display: flex;
            align-items: center;
            justify-content: center;
            z-index: 2;
        }

        .banner-graphic svg {
            width: 36px;
            height: 36px;
            color: #e2b857;
            fill: none;
            animation: fineFloat 4s infinite alternate ease-in-out;
        }

        @keyframes fineFloat {
            0% { transform: translateY(3px); }
            100% { transform: translateY(-4px); }
        }

        .banner-value {
            font-size: 1.65rem;
            font-weight: 900;
            color: #ffffff;
            letter-spacing: -0.02em;
            background: linear-gradient(135deg, #ffffff 0%, #cbd5e1 100%);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            z-index: 2;
        }

        .banner-btn {
            width: 100%;
            padding: 11px;
            background: #0b0f19;
            color: white;
            font-size: 0.78rem;
            font-weight: 800;
            text-transform: uppercase;
            letter-spacing: 0.02em;
            border-radius: 10px;
            border: 1px solid rgba(255, 255, 255, 0.06);
            transition: all 0.25s cubic-bezier(0.4, 0, 0.2, 1);
            z-index: 2;
        }

        .cards-container-banner:hover {
            border-color: rgba(226, 184, 87, 0.2);
            box-shadow: 0 16px 40px rgba(0, 0, 0, 0.5);
        }

        .cards-container-banner:hover .banner-btn {
            background: #ffffff;
            color: #0b0f19;
            border-color: #ffffff;
            box-shadow: 0 4px 14px rgba(255, 255, 255, 0.15);
        }

        /* ==========================================
           UPGRADED LUXURY GAMING ROW CARD
           ========================================== */
        .product-card {
            background: #151b2c;
            border: 1px solid rgba(255, 255, 255, 0.05);
            border-radius: 16px;
            padding: 20px 28px;
            display: grid;
            grid-template-columns: 140px auto 1fr 140px;
            align-items: center;
            gap: 28px;
            transition: all 0.25s ease;
            box-shadow: 0 4px 20px rgba(0, 0, 0, 0.1);
        }

        .product-card.hidden { display: none !important; }

        .product-card:hover {
            border-color: rgba(59, 130, 246, 0.3);
            background: #1a2238;
            transform: translateY(-1px);
        }

        .card-logo-link { display: block; }

        .logo-container {
            width: 140px;
            height: 68px;
            background-color: #0f1422;
            border: 1px solid rgba(255, 255, 255, 0.07);
            border-radius: 12px;
            display: flex;
            align-items: center;
            justify-content: center;
            overflow: hidden;
            padding: 10px;
        }

        .logo-container img { max-width: 100%; max-height: 100%; object-fit: contain; }
        .logo-separator { width: 1px; height: 48px; background: rgba(255, 255, 255, 0.08); }
        .card-info { display: flex; flex-direction: column; gap: 8px; }
        .product-name { font-size: 1.3rem; font-weight: 700; color: #ffffff; letter-spacing: -0.02em; }
        .rating-container { display: flex; align-items: center; gap: 6px; font-size: 0.85rem; color: #64748b; }
        .stars-graphic { display: flex; gap: 2px; color: #fbbf24; }
        .stars-graphic svg { width: 14px; height: 14px; fill: currentColor; }
        .rating-value { color: #cbd5e1; margin-left: 2px; }
        .badges-wrapper { display: flex; flex-wrap: wrap; gap: 8px; }

        .badge {
            font-size: 0.75rem;
            font-weight: 700;
            padding: 5px 10px;
            border-radius: 6px;
            display: inline-flex;
            align-items: center;
            gap: 5px;
        }
        .badge svg { width: 14px; height: 14px; }
        .badge-position { background: rgba(59, 130, 246, 0.1); color: #60a5fa; border: 1px solid rgba(59, 130, 246, 0.15); }
        .badge-category { background: rgba(255, 255, 255, 0.04); color: #cbd5e1; border: 1px solid rgba(255, 255, 255, 0.06); }

        /* Visit Play Button Architecture */
        .visit-btn {
            width: 140px;
            height: 44px;
            background: #3b82f6;
            color: #ffffff;
            font-weight: 700;
            font-size: 0.88rem;
            border-radius: 10px;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 6px;
            text-decoration: none;
            box-shadow: 0 4px 12px rgba(59, 130, 246, 0.2);
            transition: all 0.2s ease;
        }

        .visit-btn svg { width: 16px; height: 16px; transition: transform 0.2s ease; }
        .visit-btn:hover { background: #2563eb; }
        .visit-btn:hover svg { transform: translateX(3px); }

        /* ==========================================
           RESPONSIVE SYSTEM
           ========================================== */
        @media (max-width: 1100px) {
            .cards-container {
                grid-template-columns: 1fr;
                column-gap: 0;
            }
            .cards-container-banner { display: none; }
        }

        @media (max-width: 820px) {
            .nav-menu {
                position: fixed;
                top: 76px;
                left: -100%;
                width: 100%;
                height: calc(100vh - 76px);
                background: #0b0f19;
                flex-direction: column;
                align-items: flex-start;
                padding: 32px 24px;
                gap: 16px;
                transition: left 0.3s ease;
                border-top: 1px solid rgba(255,255,255,0.05);
            }
            .nav-menu.open { left: 0; }
            .nav-link { font-size: 1.1rem; width: 100%; padding: 12px 16px; background: rgba(255,255,255,0.02); }
            .header-cta { text-align: center; justify-content: center; margin-top: 12px; width: 100%; }
            .hamburger { display: block; }
            
            /* Add Admin link in mobile menu */
            .nav-link.admin-link {
                border-top: 1px solid rgba(255,255,255,0.06);
                margin-top: 8px;
                padding-top: 16px;
            }
        }

        @media (max-width: 680px) {
            body { padding-top: 92px; }
            .filter-wrapper { padding: 12px; gap: 10px; border-radius: 12px; }
            .search-input { height: 42px; font-size: 0.88rem; padding-left: 38px; }
            .search-icon { left: 12px; width: 16px; height: 16px; }
            .filter-pills { padding-top: 10px; gap: 6px; }
            .filter-btn { padding: 6px 14px; font-size: 0.8rem; }
            
            .product-card {
                display: flex;
                flex-direction: column;
                align-items: center;
                text-align: center;
                padding: 0;
                gap: 0;
                overflow: hidden;
            }

            .card-logo-link {
                width: 100%;
                background: rgba(0,0,0,0.1);
                padding: 24px 0;
                display: flex;
                justify-content: center;
                border-bottom: 1px solid rgba(255, 255, 255, 0.03);
            }

            .logo-container { width: 148px; height: 68px; }
            .logo-separator { display: none; }
            .card-info { padding: 20px; align-items: center; width: 100%; gap: 10px; }
            .product-name { font-size: 1.4rem; }
            .badges-wrapper { justify-content: center; }
            
            .visit-btn {
                width: calc(100% - 40px);
                height: 48px;
                font-size: 0.95rem;
                margin-bottom: 24px;
            }
        }
    </style>
</head>
<body>

    <!-- Premium Navigation Setup -->
    <header class="site-header">
        <div class="header-container">
            <a href="#" class="brand-logo">
                <div class="brand-logo-icon">
                    <svg width="20" height="20" viewBox="0 0 24 24" fill="#fff"><path d="M2 4l3 12h14l3-12-6 7-4-7-4 7-6-7zm3 14h14v2H5v-2z"/></svg>
                </div>
                11/22 <span>Luck</span>
            </a>
            
            <button class="hamburger" id="hamburgerMenuBtn" aria-label="Toggle navigation menu">
                <div class="hamburger-box">
                    <div class="hamburger-inner"></div>
                    <div class="hamburger-inner"></div>
                    <div class="hamburger-inner"></div>
                </div>
            </button>

            <ul class="nav-menu" id="navMenu">
                <li><a href="#" class="nav-link active">
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="3" width="18" height="18" rx="2" ry="2"/><line x1="9" y1="3" x2="9" y2="21"/><line x1="15" y1="3" x2="15" y2="21"/><line x1="3" y1="9" x2="21" y2="9"/><line x1="3" y1="15" x2="21" y2="15"/></svg>
                    Slots
                </a></li>
                <li><a href="#" class="nav-link">
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"/><circle cx="12" cy="12" r="6"/><path d="M12 2v4M12 18v4M2 12h4M18 12h4"/></svg>
                    Live Casino
                </a></li>
                <li><a href="#" class="nav-link header-cta">
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><polyline points="20 12 20 22 4 22 4 12"/><rect x="2" y="7" width="20" height="5"/><line x1="12" y1="22" x2="12" y2="7"/><path d="M12 7H7.5a2.5 2.5 0 0 1 0-5C11 2 12 7 12 7z"/><path d="M12 7h4.5a2.5 2.5 0 0 0 0-5C13 2 12 7 12 7z"/></svg>
                    VIP Space
                </a></li>
                <li><a href="admin/index.php" class="nav-link" style="color: #60a5fa;">
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M12 15v2m-6 4h12a2 2 0 0 0 2-2v-6a2 2 0 0 0-2-2H6a2 2 0 0 0-2 2v6a2 2 0 0 0 2 2zm10-10V7a4 4 0 0 0-8 0v4h8z"/></svg>
                    Admin
                </a></li>
            </ul>
        </div>
    </header>

    <!-- Category Filter Shell -->
    <div class="filter-wrapper">
        <div class="search-container">
            <svg class="search-icon" viewBox="0 0 24 24" stroke-width="2.5" fill="none" stroke="currentColor"><circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/></svg>
            <input type="text" id="searchInput" class="search-input" placeholder="Search betting platforms...">
        </div>
        <div class="filter-pills">
            <button class="filter-btn active" data-filter="all">
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="3" width="7" height="7"/><rect x="14" y="3" width="7" height="7"/><rect x="14" y="14" width="7" height="7"/><rect x="3" y="14" width="7" height="7"/></svg>
                All Offers
            </button>
            <button class="filter-btn" data-filter="slots">
                <svg viewBox="0 0 24 24" fill="currentColor"><circle cx="6" cy="18" r="4"/><circle cx="18" cy="16" r="4"/><path d="M6 14V4c0-1 1-2 2-2h8c1 0 2 1 2 2v10" fill="none" stroke="currentColor" stroke-width="2"/></svg>
                Slots
            </button>
            <button class="filter-btn" data-filter="sports">
                <svg viewBox="0 0 24 24" fill="currentColor"><path d="M12 2C9 7 4 10 4 14c0 4.5 3.5 6 8 6s8-1.5 8-6c0-4-5-7-8-12z"/><path d="M10 19l-2 3h8l-2-3z"/></svg>
                Sportsbook
            </button>
            <button class="filter-btn" data-filter="crypto">
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"/><path d="M12 6v12M9 10h6M9 14h6"/></svg>
                Crypto Play
            </button>
            <button class="filter-btn" data-filter="casino">
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="3" width="18" height="18" rx="2" ry="2"/><path d="M7 7h.01M17 7h.01M7 17h.01M17 17h.01M12 12h.01"/></svg>
                Live Casino
            </button>
        </div>
    </div>

    <!-- MAIN GRID CONTAINER -->
    <div class="cards-container" id="cardsContainer">
        
        <!-- LEFT ANCHORED ADVERTISING BANNER -->
        <a href="#promo1" class="cards-container-banner">
            <div class="banner-glow-element"></div>
            <div class="banner-tag">Hot Drop</div>
            <div class="banner-title">Mega Win<span>Jackpot Slots</span></div>
            <div class="banner-graphic">
                <svg viewBox="0 0 24 24" stroke="currentColor" stroke-width="2"><rect x="3" y="3" width="18" height="18" rx="2"/><line x1="9" y1="3" x2="9" y2="21"/><line x1="15" y1="3" x2="15" y2="21"/><line x1="3" y1="12" x2="21" y2="12"/></svg>
            </div>
            <div class="banner-value">250 FS</div>
            <div class="banner-btn">Claim Spins</div>
        </a>

        <!-- CENTER CARDS ROW COLUMN FEED -->
        <div class="cards-feed-column">
            
            <?php if (empty($cards)): ?>
                <div style="text-align:center; padding:60px 20px; color:#94a3b8;">
                    <h3 style="color:#f8fafc; margin-bottom:10px;">No casino cards available</h3>
                    <p>Please check back later for our premium casino recommendations.</p>
                </div>
            <?php else: ?>
                <?php foreach ($cards as $card): ?>
                    <!-- Card from Database -->
                    <div class="product-card" data-category="<?php echo htmlspecialchars($card['category']); ?>" data-name="<?php echo htmlspecialchars(strtolower($card['name'])); ?>">
                        <a href="<?php echo htmlspecialchars($card['card_link']); ?>" class="card-logo-link" target="_blank" rel="noopener noreferrer">
                            <div class="logo-container">
                                <?php if (filter_var($card['logo_url'], FILTER_VALIDATE_URL)): ?>
                                    <img src="<?php echo htmlspecialchars($card['logo_url']); ?>" alt="<?php echo htmlspecialchars($card['name']); ?> Logo">
                                <?php else: ?>
                                    <span style="color:#60a5fa; font-weight:800; font-size:1.1rem;"><?php echo htmlspecialchars($card['name']); ?></span>
                                <?php endif; ?>
                            </div>
                        </a>
                        <div class="logo-separator"></div>
                        <div class="card-info">
                            <div class="product-name"><?php echo htmlspecialchars($card['name']); ?></div>
                            <div class="rating-container">
                                <div class="stars-graphic">
                                    <?php echo generateStars($card['rating']); ?>
                                </div>
                                <span class="rating-value"><?php echo number_format($card['rating'], 1); ?></span>
                            </div>
                            <div class="badges-wrapper">
                                <?php if ($card['badge_1']): ?>
                                    <span class="badge badge-<?php echo $card['badge_1_type'] === 'position' ? 'position' : 'category'; ?>">
                                        <?php echo htmlspecialchars($card['badge_1']); ?>
                                    </span>
                                <?php endif; ?>
                                <?php if ($card['badge_2']): ?>
                                    <span class="badge badge-<?php echo $card['badge_2_type'] === 'position' ? 'position' : 'category'; ?>">
                                        <?php echo htmlspecialchars($card['badge_2']); ?>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>
                        <a href="<?php echo htmlspecialchars($card['card_link']); ?>" class="visit-btn" target="_blank" rel="noopener noreferrer">
                            <span>Play Now</span>
                            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"><line x1="5" y1="12" x2="19" y2="12"/><polyline points="12 5 19 12 12 19"/></svg>
                        </a>
                    </div>
                <?php endforeach; ?>
            <?php endif; ?>

        </div>

        <!-- RIGHT ANCHORED ADVERTISING BANNER -->
        <a href="#promo2" class="cards-container-banner">
            <div class="banner-glow-element" style="background:#3b82f6;"></div>
            <div class="banner-tag" style="color:#60a5fa; background:rgba(59,130,246,0.08); border-color:rgba(59,130,246,0.15)">VIP Promo</div>
            <div class="banner-title">New Player<span>Club Rewards</span></div>
            <div class="banner-graphic">
                <svg viewBox="0 0 24 24" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"/><path d="M12 6v12M9 10h6M9 14h6"/></svg>
            </div>
            <div class="banner-value">+200%</div>
            <div class="banner-btn">Get Bonus</div>
        </a>

    </div>

    <!-- Interface Filtering & Mobile Control Logic -->
    <script>
        const hamburgerBtn = document.getElementById('hamburgerMenuBtn');
        const navMenu = document.getElementById('navMenu');

        hamburgerBtn.addEventListener('click', () => {
            hamburgerBtn.classList.toggle('open');
            navMenu.classList.toggle('open');
        });

        const searchInput = document.getElementById('searchInput');
        const filterButtons = document.querySelectorAll('.filter-btn');
        const productCards = document.querySelectorAll('.product-card');

        let currentFilter = 'all';
        let currentSearchQuery = '';

        function applyFilters() {
            productCards.forEach(card => {
                const cardCategory = card.getAttribute('data-category');
                const cardName = card.getAttribute('data-name').toLowerCase();
                
                const matchesCategory = (currentFilter === 'all' || cardCategory === currentFilter);
                const matchesSearch = cardName.includes(currentSearchQuery);

                if (matchesCategory && matchesSearch) {
                    card.classList.remove('hidden');
                } else {
                    card.classList.add('hidden');
                }
            });
        }

        filterButtons.forEach(button => {
            button.addEventListener('click', () => {
                filterButtons.forEach(btn => btn.classList.remove('active'));
                button.classList.add('active');
                currentFilter = button.getAttribute('data-filter');
                applyFilters();
            });
        });

        searchInput.addEventListener('input', (e) => {
            currentSearchQuery = e.target.value.toLowerCase().trim();
            applyFilters();
        });
    </script>
</body>
</html>